Special Needs Analysis Calculator README

Welcome!