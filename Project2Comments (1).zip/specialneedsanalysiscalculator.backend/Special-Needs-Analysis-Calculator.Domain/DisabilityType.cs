﻿namespace Special_Needs_Analysis_Calculator.Domain
{
    // May not need, fields are stored in Beneficiary model / Conditional status
    public enum DisabilityType
    {
        Temporary,
        Permanent
    }
}
